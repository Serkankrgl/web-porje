<html>
    <head>

    </head>
    <body>
        
            <img src="../../Public/Media/HG.jpg" width="500"> <br>
            <?php
            echo " B181210050 Numaralı Kullanıcı";
            ?>
        
    </body>
</html>
<?php
